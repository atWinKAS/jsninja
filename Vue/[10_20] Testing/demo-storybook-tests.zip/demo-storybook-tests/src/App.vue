
<template>
    <div class="app">
    App start
    <Panel>
      <span slot="title">Button demo <button @click="hi()">Button</button></span>
      <ul>
        <li>Foo</li>
        <li>Bar</li>
        <li>Baz</li>
      </ul>
    </Panel>
    <List :items="users">
      <span slot="title">Demo list</span>
      <template slot="item" slot-scope="rowItem">
        <span>{{ msg }} -  {{ rowItem.index }} = {{ rowItem.item.name}} -- <i>{{ rowItem.item.username }}</i></span>
      </template>
    </List>
    </div>
</template>

<script>
import Panel from '@/components/Panel';
import List from '@/components/List/List';
import usersMixin from './mixins/uselessMixin';

export default {
  name: 'App',
  mixins: [usersMixin],
  components: {
    Panel,
    List,
  },

  data() {
    return {
      msg: 'Welcome to App',
    };
  },
};
</script>

<style>
.app {
  border: solid blue 3px;
  padding: 5px;
}
</style>
