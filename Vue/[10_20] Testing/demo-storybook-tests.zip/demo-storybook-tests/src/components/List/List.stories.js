import Vue from 'vue';
import { storiesOf } from '@storybook/vue';
import { action } from '@storybook/addon-actions';

import List from './List.vue';

storiesOf('List', module).add('displays title', () => ({
  components: { List },
  methods: {
    handleClick: action('clicked'),
  },
  template: `
    <List :items="[]">
      <span slot="title">Demo list <button @click="handleClick">Demo</button></span>
    </List>
  `,
}));

storiesOf('List', module).add('displays customizable item', () => ({
  components: { List },
  data() {
    return {
      items: [{ id: 1, name: 'Vasya' }, { id: 2, name: 'Petya' }],
    };
  },
  template: `
    <List :items="items">
      <span slot="title">Demo list</span>
      <template slot="item" slot-scope="rowItem">
        <span>{{ rowItem.index }} = {{ rowItem.item.name}}</span>
      </template>
    </List>
  `,
}));

storiesOf('List', module).add(
  'emits itemselect event when clicked on item',
  () => ({
    components: { List },
    data() {
      return {
        items: [{ id: 1, name: 'Vasya' }, { id: 2, name: 'Petya' }],
      };
    },
    methods: {
      handleItemClick: action('itemclick'),
    },
    template: `
    <List :items="items" @itemclick="handleItemClick">
      <template slot="item" slot-scope="rowItem">
        <span>{{ rowItem.index }} = {{ rowItem.item.name}}</span>
      </template>
    </List>
  `,
  }),
);
