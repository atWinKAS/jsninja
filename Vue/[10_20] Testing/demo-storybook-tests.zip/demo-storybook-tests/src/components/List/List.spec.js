import List from './List.vue';
import { shallow } from '@vue/test-utils';

function shallowEquals(a, b) {
  return (
    Object.keys(a).length === Object.keys(b).length &&
    Object.keys(a).every(k => a[k] === b[k])
  );
}

describe('List.vue', () => {
  it('renders li for each item in props.items', () => {
    // Arrange
    const items = ['a', 'b'];

    // Act
    const wrapper = shallow(List, {
      propsData: { items },
    });

    // Assert
    expect(wrapper.findAll('li')).toHaveLength(items.length);
  });

  it('renders No data message when items are empty', () => {
    // Arrange
    const items = [];

    // Act
    const wrapper = shallow(List, {
      propsData: { items },
    });

    // Assert
    expect(wrapper.find('ul').text()).toMatch('Nod data');
  });
});
