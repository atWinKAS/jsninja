<template>
  <div class="list">
    <h1><slot name="title"></slot></h1>
    <hr/>
    <ul>
      <template v-if="items.length">
      <li @click="$emit('itemclick', item)" :key="item.id" v-for="(item, idx) in items">
        <slot name="item" :index="idx" :item="item"></slot>
      </li>
      </template>
      <template v-if="!items.length">
        Nod data
      </template>
    </ul>
  </div>
</template>

<script>
/* rows: [
  { field: 'price', width: '...' },
  { field: 'name', width: '...' },
] */

export default {
  name: 'List',
  props: {
    items: Array,
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.panel {
  border: solid red 3px;
}
</style>
