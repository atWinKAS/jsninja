<template>
  <div class="panel">
    <h1><slot name="title"></slot></h1>
    <h2><slot name="subtitle">Subtitle default</slot></h2>
    <hr/>
    <p><slot></slot></p>
  </div>
</template>

<script>
export default {
  name: 'Panel',
  data() {
    return {
      msg: 'Welcome to Panel',
    };
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.panel {
  border: solid red 3px;
}
</style>
