<template>
  <div id="app">
    <img src="./assets/logo.png">
    <button @click="showHelloWorld = true">Нажми меня</button>
    <template v-if="showHelloWorld">
      <Ninja/>
      <HelloWorld/>
    </template>
  </div>
</template>

<script>
import Spinner from './components/Spinner';
import Error from './components/Error';
export default {
  name: 'App',
  data() {
    return { showHelloWorld: false };
  },
  components: {
    Spinner,
    HelloWorld: () => ({
      component: import(/* webpackChunkName: "admin-bundle" */ './components/HelloWorld'),
      loading: Spinner,
      delay: 500,
      error: Error,
      timeout: 3000, // Infinity
    }),
    Ninja: () =>
      import(/* webpackChunkName: "admin-bundle" */ './components/Ninja'),
  },
};
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
