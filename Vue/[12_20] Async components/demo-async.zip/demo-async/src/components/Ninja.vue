<template>
  <h1>Ninja rulez! Vue rulez!</h1>
</template>
<script>
export default {};
</script>