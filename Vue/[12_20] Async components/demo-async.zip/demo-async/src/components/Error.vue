<template>
  <h1>Loading took too long :( ...</h1>
</template>
<script>
export default {};
</script>