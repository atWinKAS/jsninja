<template>
  <div class="list">
    <h1><slot name="title"></slot></h1>
    <hr/>
    <ul>
      <li :key="item.id" v-for="(item, idx) in items">
        <slot name="item" :index="idx" :item="item"></slot>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'List',
  props: {
    items: Array,
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.panel {
  border: solid red 3px;
}
</style>
