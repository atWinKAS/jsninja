export default {
  data() {
    return {
      users: [],
      loading: true,
    };
  },

  async mounted() {
    this.users = await fetch('http://jsonplaceholder.typicode.com/users').then(
      r => r.json(),
    );
  },
};
